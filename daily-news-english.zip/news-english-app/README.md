# Daily News English 📰 v2

Learn English through today's real news headlines — CNN English Express style.
Powered by **NewsData.io** (free news + images) + **Claude Haiku** (fast & cheap AI lessons).

## Features
- 🖼️ CNN-style article cards with real news photos
- 🌍 4 categories: World, Business, Tech, Sports
- 🔤 Key vocabulary with カタカナ pronunciation & examples
- 📐 Grammar point breakdowns with structure analysis
- 🇯🇵 Full Japanese translation
- ✅ Interactive comprehension quiz
- ⚡ Server-side caching (1 API call per category per hour)

## Cost Structure

| Component | Service | Monthly Cost |
|-----------|---------|-------------|
| News + Images | NewsData.io Free | **$0** |
| Lesson AI | Claude Haiku (cached) | **~$1** |
| Hosting | Netlify Free | **$0** |
| **Total** | | **~$1/month** |

## Deploy to Netlify

### 1. Get API Keys

**NewsData.io** (free):
1. Sign up at https://newsdata.io/register
2. Copy your API key from the dashboard

**Anthropic** (for Claude Haiku):
1. Go to https://console.anthropic.com/settings/keys
2. Create a new API key

### 2. Push to GitHub
```bash
cd daily-news-english
git init
git add .
git commit -m "initial commit"
gh repo create daily-news-english --public --push
```

### 3. Deploy on Netlify
1. Go to [app.netlify.com](https://app.netlify.com)
2. Click **"Add new site" → "Import an existing project"**
3. Select your GitHub repo
4. Deploy settings are auto-configured via `netlify.toml`

### 4. Set Environment Variables
In Netlify: **Site settings → Environment variables**, add:

| Key | Value |
|-----|-------|
| `NEWSDATA_API_KEY` | Your NewsData.io API key |
| `ANTHROPIC_API_KEY` | Your Anthropic API key (`sk-ant-...`) |

### 5. Redeploy
Trigger a redeploy after adding env vars. Done!

## Project Structure
```
daily-news-english/
├── public/
│   └── index.html              # Frontend (React via CDN, no build step)
├── netlify/
│   └── functions/
│       ├── news.js             # NewsData.io proxy + cache
│       └── lesson.js           # Claude Haiku lesson generator + cache
├── netlify.toml                # Netlify config & URL redirects
├── package.json
└── README.md
```

## How It Works

```
User clicks "Get Today's News"
        │
        ▼
  /api/news?category=world
        │
   ┌────┴────┐
   │ Cached?  │──Yes──▶ Return cached articles (with images)
   └────┬────┘
        │ No
        ▼
  NewsData.io API (free)
  → Returns articles + thumbnail images
  → Cache for 1 hour
        │
        ▼
  User clicks article
        │
        ▼
  /api/lesson (POST)
        │
   ┌────┴────┐
   │ Cached?  │──Yes──▶ Return cached lesson
   └────┬────┘
        │ No
        ▼
  Claude Haiku generates:
  → English paragraph + 日本語訳
  → Vocabulary list
  → Grammar breakdown
  → Quiz questions
  → Cache for 24 hours
```

## API Keys Stay Safe
- API keys are stored as Netlify environment variables (server-side only)
- The frontend calls `/api/news` and `/api/lesson` (your Netlify Functions)
- Keys are never exposed to browsers

## Upgrade Path
- **Persistent cache**: Add [Netlify Blobs](https://docs.netlify.com/blobs/overview/) for cache that survives function cold starts
- **Scheduled generation**: Use [Netlify Scheduled Functions](https://docs.netlify.com/functions/scheduled-functions/) to pre-generate all lessons daily at midnight
- **Better model**: Switch `claude-haiku-4-5-20251001` to `claude-sonnet-4-20250514` in `lesson.js` for higher quality (costs ~10x more)
